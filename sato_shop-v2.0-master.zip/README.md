
 чтобы запустить нужно:
- `python3 -m venv ДиректорияВиртуальногоОкружения`
- `source ДиректорияВиртуальногоОкружения/bin/activate`
-  Перейти в директорию проекта и выполнить следующие команды
- `pip install -r requirements.txt`
- `python manage.py migrate`
` python manage.py createsuperuser`  и войти под админом да потестировать
 Запустить сервер - `python manage.py runserver`
 